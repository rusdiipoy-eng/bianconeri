(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg = function() {
	this.initialize(img.bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.bgb = function() {
	this.initialize(img.bgb);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.bgc = function() {
	this.initialize(img.bgc);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.bgred = function() {
	this.initialize(img.bgred);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.fog = function() {
	this.initialize(img.fog);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.FoldingPaper09 = function() {
	this.initialize(img.FoldingPaper09);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib.FoldingPaper10 = function() {
	this.initialize(img.FoldingPaper10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib.FoldingPaper11 = function() {
	this.initialize(img.FoldingPaper11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib.FoldingPaper12 = function() {
	this.initialize(img.FoldingPaper12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib.FoldingPaper13 = function() {
	this.initialize(img.FoldingPaper13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib.frame = function() {
	this.initialize(img.frame);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,1200);


(lib.kotakmerah2 = function() {
	this.initialize(img.kotakmerah2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,1200);


(lib.L = function() {
	this.initialize(img.L);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,297,326);


(lib.logo21 = function() {
	this.initialize(img.logo21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.R = function() {
	this.initialize(img.R);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,299,326);


(lib.shadowtalent = function() {
	this.initialize(img.shadowtalent);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.sko = function() {
	this.initialize(img.sko);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.t1 = function() {
	this.initialize(img.t1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,750);


(lib.t2 = function() {
	this.initialize(img.t2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,750);


(lib.t3 = function() {
	this.initialize(img.t3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,750);


(lib.text1 = function() {
	this.initialize(img.text1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.text2 = function() {
	this.initialize(img.text2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.Tween29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.R();
	this.instance.setTransform(-160,-174.45,1.0702,1.0702);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-174.4,320,348.9);


(lib.Tween28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.L();
	this.instance.setTransform(-160,-175.6,1.0774,1.0774);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-175.6,320,351.29999999999995);


(lib.Tween27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.R();
	this.instance.setTransform(-124.5,-135.75,0.833,0.833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-124.5,-135.7,249.1,271.5);


(lib.Tween26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.L();
	this.instance.setTransform(-124.5,-136.7,0.8386,0.8386);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-124.5,-136.7,249.1,273.4);


(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.fog();
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadowtalent();
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bgc();
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bgb();
	this.instance.setTransform(-160,-240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t2();
	this.instance.setTransform(-160,-240,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.kotakmerah2();
	this.instance.setTransform(-160,-240,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cta();
	this.instance.setTransform(-160,-240,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,320,480);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t3();
	this.instance.setTransform(-140.25,-209.9,0.56,0.56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140.2,-209.9,280,420);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1();
	this.instance.setTransform(-140.05,-210.25,0.56,0.56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-210.2,280,420);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.frame();
	this.instance.setTransform(-160,-240,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,400,600);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg();
	this.instance.setTransform(-160,-240,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,160,240);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(-159.95,-240,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-159.9,-240,160,240);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text1();
	this.instance.setTransform(-160,-240,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-240,160,240);


// stage content:
(lib._320x480 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ghw
	this.instance = new lib.logo21();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(205));

	// bgred
	this.instance_1 = new lib.bgred();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(205));

	// cta
	this.instance_2 = new lib.Tween17("synched",0);
	this.instance_2.setTransform(161.8,427.7,0.8295,0.8295,0,0,0,1.8,187.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(95).to({_off:false},0).to({regX:1.6,regY:187.5,scaleX:1,scaleY:1,x:161.6,y:427.5},7,cjs.Ease.backOut).to({regY:187.7,scaleX:0.9174,scaleY:0.9174,y:427.6},8,cjs.Ease.sineOut).to({regX:1.7,regY:187.8,scaleX:0.8884,scaleY:0.8884,x:161.7,y:427.7},9,cjs.Ease.backInOut).to({regX:1.6,regY:187.5,scaleX:1,scaleY:1,x:161.6,y:427.5},10,cjs.Ease.backOut).to({regX:1.7,regY:187.8,scaleX:0.8884,scaleY:0.8884,x:161.7,y:427.7},11,cjs.Ease.backOut).to({regX:1.6,regY:187.5,scaleX:1,scaleY:1,x:161.6,y:427.5},12,cjs.Ease.backOut).to({regX:1.7,regY:187.8,scaleX:0.8884,scaleY:0.8884,x:161.7,y:427.7},15,cjs.Ease.backOut).to({regX:1.6,regY:187.5,scaleX:1,scaleY:1,x:161.6,y:427.5},16,cjs.Ease.backOut).to({regX:1.7,regY:187.8,scaleX:0.8884,scaleY:0.8884,x:161.7,y:427.7},16,cjs.Ease.backOut).wait(6));

	// Layer_14
	this.instance_3 = new lib.FoldingPaper09();
	this.instance_3.setTransform(0,0,0.8,0.8);

	this.instance_4 = new lib.FoldingPaper10();
	this.instance_4.setTransform(0,0,0.8,0.8);

	this.instance_5 = new lib.FoldingPaper11();
	this.instance_5.setTransform(0,0,0.8,0.8);

	this.instance_6 = new lib.FoldingPaper12();
	this.instance_6.setTransform(0,0,0.8,0.8);

	this.instance_7 = new lib.FoldingPaper13();
	this.instance_7.setTransform(0,0,0.8,0.8);

	this.instance_8 = new lib.sko();
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},49).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(151));

	// text1_png
	this.instance_9 = new lib.Tween1("synched",0);
	this.instance_9.setTransform(151.2,69.05,0.3189,0.3189,0,0,0,-84.4,-205.4);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(4).to({_off:false},0).to({regX:-84.1,regY:-205.2,scaleX:1.9787,scaleY:1.9787,x:151.65,y:69.45,alpha:1},6,cjs.Ease.sineOut).to({regY:-205.1,scaleX:2.2882,scaleY:2.2882,x:151.5,y:69.55},8).to({regX:-84.4,regY:-205.5,scaleX:2.0002,scaleY:2.0002,x:151.25,y:68.95},4).wait(183));

	// text2_png
	this.instance_10 = new lib.Tween2("synched",0);
	this.instance_10.setTransform(158.75,102.9,1.5149,1.5133,0,0,0,-80.6,-188.5);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({_off:false},0).to({regX:-80.7,regY:-188.6,scaleX:2.0361,scaleY:2.0341,x:158.55,y:102.85,alpha:1},3).to({startPosition:0},3).to({regX:-80.6,regY:-188.5,scaleX:1.4506,scaleY:1.4491,x:158.6,y:103},9,cjs.Ease.sineOut).to({regX:-80.7,regY:-188.6,scaleX:1.9999,scaleY:1.9979,y:102.95},4,cjs.Ease.sineIn).wait(174));

	// Layer_8
	this.instance_11 = new lib.Tween28("synched",0);
	this.instance_11.setTransform(-24.5,325.6,0.3289,0.298,0,0,0,-144,152.1);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(65).to({_off:false},0).to({scaleX:1,scaleY:1,rotation:-7.9501,x:-24.55,y:325.7,alpha:1},28,cjs.Ease.sineOut).to({regX:-143.8,scaleX:1.12,scaleY:1.12,rotation:12.2564,x:-24.5,y:325.65},62,cjs.Ease.sineOut).to({regX:-143.7,regY:152.2,scaleX:1.167,scaleY:1.167,rotation:-6.9498,x:-24.4,y:325.8},49).wait(1));

	// Layer_7
	this.instance_12 = new lib.Tween29("synched",0);
	this.instance_12.setTransform(341.55,310.45,0.2126,0.1925,0,0,0,141.1,149.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(65).to({_off:false},0).to({regY:150,scaleX:1,scaleY:1,rotation:1.7471,x:341.6,alpha:1},28,cjs.Ease.sineOut).to({regX:141,regY:150.1,rotation:-9.9645,x:341.45,y:310.65},62,cjs.Ease.sineOut).to({regX:141.2,regY:150.2,scaleX:1.1391,scaleY:1.1391,rotation:7.9781,x:341.7,y:310.75},49).wait(1));

	// talent_1
	this.instance_13 = new lib.Tween13("synched",0);
	this.instance_13.setTransform(379.25,426.95,1.8995,1.8995,0,0,0,59.1,-7.8);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(33).to({_off:false},0).to({regX:59,scaleX:1.138,scaleY:1.138,x:227.15,y:231.1},23).to({scaleX:1.1996,scaleY:1.1996,x:230.8,y:234.65},148).wait(1));

	// Layer_5
	this.instance_14 = new lib.Tween19("synched",0);
	this.instance_14.setTransform(160.15,242.9,0.9294,0.9294,0,0,0,0.2,0.1);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(87).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:160,y:240,alpha:1},12,cjs.Ease.sineOut).to({scaleX:1.0542,scaleY:1.0542,y:244},105).wait(1));

	// Layer_1
	this.instance_15 = new lib.Tween21("synched",0);
	this.instance_15.setTransform(128.9,635.95,2.2289,2.2289);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(37).to({_off:false},0).to({scaleX:1,scaleY:1,x:160,y:240},23,cjs.Ease.sineOut).to({scaleX:1.0542,scaleY:1.0542,y:244},144).wait(1));

	// talent_2
	this.instance_16 = new lib.Tween12("synched",0);
	this.instance_16.setTransform(-60.8,532.1,2.9306,2.9306,0,0,0,-50.5,-6);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(26).to({_off:false},0).to({regX:-50.6,scaleX:1.1429,scaleY:1.1429,x:102.2,y:233.45},23,cjs.Ease.sineOut).to({scaleX:1.2047,scaleY:1.2047,x:99.1,y:237.05},155).wait(1));

	// footshadow
	this.instance_17 = new lib.Tween24("synched",0);
	this.instance_17.setTransform(160,240);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(49).to({_off:false},0).to({alpha:1},17).to({scaleX:1.0542,scaleY:1.0542,y:244},138).wait(1));

	// frame
	this.instance_18 = new lib.Tween8("synched",0);
	this.instance_18.setTransform(170.05,255.1,0.1353,0.1353,0,0,0,61.4,89.4);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(57).to({_off:false},0).to({regY:89.5,scaleX:0.8,scaleY:0.7999,x:177.1,y:263.55},42,cjs.Ease.sineOut).to({scaleX:0.8433,scaleY:0.8432,x:178.05,y:268.75},105).wait(1));

	// fog
	this.instance_19 = new lib.Tween25("synched",0);
	this.instance_19.setTransform(160,240);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(78).to({_off:false},0).to({alpha:0.6484},21).wait(106));

	// Layer_8
	this.instance_20 = new lib.Tween26("synched",0);
	this.instance_20.setTransform(35,295.7,0.3125,0.3125,0,0,0,-98.1,108);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(65).to({_off:false},0).to({regX:-97.9,regY:108.2,scaleX:1.0247,scaleY:1.0247,x:35.15,y:295.85,alpha:1},18,cjs.Ease.sineOut).to({regX:-97.7,regY:108.4,scaleX:1.1391,scaleY:1.1391,rotation:-12.6931,x:35.4,y:296},58,cjs.Ease.sineOut).to({regY:108.5,rotation:2.7687,x:35.35,y:296.15},63).wait(1));

	// Layer_7
	this.instance_21 = new lib.Tween27("synched",0);
	this.instance_21.setTransform(302,298.55,0.2282,0.2282,0,0,0,107,112.9);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(65).to({_off:false},0).to({regY:113,scaleX:1,scaleY:1,y:298.6,alpha:1},18,cjs.Ease.sineOut).to({regX:107.1,scaleX:1.1512,scaleY:1.1512,rotation:10.7013,x:302.15},58,cjs.Ease.sineOut).to({regX:107.2,regY:113.1,rotation:-1.9963,x:302.3,y:298.7},63).wait(1));

	// bgglow
	this.instance_22 = new lib.Tween23("synched",0);
	this.instance_22.setTransform(160,240);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(41).to({_off:false},0).to({alpha:1},28).to({scaleX:1.0708,scaleY:1.0708,x:156,y:247},135).wait(1));

	// bgtrigger
	this.instance_23 = new lib.Tween22("synched",0);
	this.instance_23.setTransform(160,240);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(23).to({_off:false},0).to({alpha:1},36).to({alpha:0},9).to({_off:true},1).wait(136));

	// bg
	this.instance_24 = new lib.Tween7("synched",0);
	this.instance_24.setTransform(160.2,251.6,1.9999,1.9999,0,0,0,-79.9,-114.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({_off:true},70).wait(135));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-163.2,137,695.5999999999999,1033.9);
// library properties:
lib.properties = {
	id: 'DA1FF56CC56CB14AA9B38A85BC8B1ECE',
	width: 320,
	height: 480,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg.jpg", id:"bg"},
		{src:"images/bgb.jpg", id:"bgb"},
		{src:"images/bgc.jpg", id:"bgc"},
		{src:"images/bgred.png", id:"bgred"},
		{src:"images/cta.png", id:"cta"},
		{src:"images/fog.png", id:"fog"},
		{src:"images/FoldingPaper09.png", id:"FoldingPaper09"},
		{src:"images/FoldingPaper10.png", id:"FoldingPaper10"},
		{src:"images/FoldingPaper11.png", id:"FoldingPaper11"},
		{src:"images/FoldingPaper12.png", id:"FoldingPaper12"},
		{src:"images/FoldingPaper13.png", id:"FoldingPaper13"},
		{src:"images/frame.png", id:"frame"},
		{src:"images/kotakmerah2.png", id:"kotakmerah2"},
		{src:"images/L.png", id:"L"},
		{src:"images/logo21.png", id:"logo21"},
		{src:"images/R.png", id:"R"},
		{src:"images/shadowtalent.png", id:"shadowtalent"},
		{src:"images/sko.png", id:"sko"},
		{src:"images/t1.png", id:"t1"},
		{src:"images/t2.png", id:"t2"},
		{src:"images/t3.png", id:"t3"},
		{src:"images/text1.png", id:"text1"},
		{src:"images/text2.png", id:"text2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DA1FF56CC56CB14AA9B38A85BC8B1ECE'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;